# hack-font-ligature-nerd-font
Nerd font patched Hack font with ligatures

Manually patched [Hack](https://github.com/source-foundry/Hack) font for all
[NerdFont](https://nerdfonts.com/) goodness.

Hack is available on the nerdFont website, but not the version with ligatures.
The ligatured version was provided by
[@vikky49](https://github.com/vikky49/patchedFonts-Ligatures)!
Using the ligature enabled version of 

![capture](cap2.png)
